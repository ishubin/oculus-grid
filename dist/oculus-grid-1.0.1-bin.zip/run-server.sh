java -jar oculus-grid.jar server $* 
