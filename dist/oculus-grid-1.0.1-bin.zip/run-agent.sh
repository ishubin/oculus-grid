java -jar oculus-grid.jar agent $* 
